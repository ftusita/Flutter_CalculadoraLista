import 'package:flutter/material.dart';
import 'package:flutter_calculadora_imc/pages/calculadora_page.dart';
import 'package:flutter_calculadora_imc/pages/lista_page.dart'; // Importe a classe ListaPage
import 'package:flutter_calculadora_imc/pages/constants.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculadora IMC',
      theme: ThemeData.dark().copyWith(
        primaryColor: backgroundColor,
        scaffoldBackgroundColor: backgroundColor,
        appBarTheme: const AppBarTheme().copyWith(
          backgroundColor: backgroundColor,
        ),
      ),
      routes: {
        '/': (context) => const CalculadoraPage(), // Rota da calculadora IMC
        '/lista': (context) => ListaPage(), // Rota da lista de contatos
      },
      
    );
  }
}